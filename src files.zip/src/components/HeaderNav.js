import React,{useState} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../App.css';
import  { Component } from 'react';

import { Container, Row, Col} from 'reactstrap';
import 'bootstrap/dist/css/bootstrap.css';
import AboutUs from './AboutUs';


import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  
  NavItem,
  NavLink,
  UncontrolledDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
  NavbarText
} from 'reactstrap';

import {Link, NavLink as RRNavLink } from 'react-router-dom';
import { Jumbotron, Nav } from 'react-bootstrap';

function HeaderNav() {
  const [isOpen, setIsOpen] = useState(false);

  const toggle = () => setIsOpen(!isOpen);
  



    return (
        
    
       

<div className="container-fluid">
<headerNavBar>
 
    
      <div >
        <div>
        <Link to='/Home'>   <button type="button" class="headerBtn">Home</button> </Link>
        <Link to='/AboutUs'>  <button type="button" class="headerBtn">About Us</button> </Link>
       
        <Link to='/Benefits'>   <button type="button" class="headerBtn">Benefits</button> </Link>
        </div>
      
      </div>
     
      
  
      </headerNavBar>

      </div>


    );
  }



export default HeaderNav;