
import React,{useState} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../App.css';





class AboutUs extends React.Component {
   
  render() {

    return (
     
      <div className="container aboutUsImg">
      
       <div>
      <p>KAPIDO</p>
      <p>GSTIN : 29CDNPR0659G1Z0</p>
      <p>Owner : Rajathgowda HR</p>
      <p>KAPIDO , our coffee products are an results of 
        the best coffee extracts from the the hills of Chikmaglur , Karnataka.
        Most of the world's best coffee products are from Chikmaglur. 
        This is our initiative to provide our customers the best coffee they ever had!
        Contact us for more info.
      </p>
      <p>
      <div className="fssai"></div> All our products are FSSAI licensed.
      </p>
      <div>
        Our Products
        <ul>
          <li>Coffee Powder</li>
          <li>Coffee Dip Bag</li>
        </ul>
      </div>

<div>
  Phone No : +91 99642 77974
</div>




       </div>
       
        </div>
       
    );
  }
}


export default AboutUs;