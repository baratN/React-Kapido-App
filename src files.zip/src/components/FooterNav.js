import React from 'react';

import  '../FooterNav.css';





class FooterNav extends React.Component {
    render() {

        return (
          <div className="main-footer">
              <div className="container">
                  <div className="row">
                      <div className="col"></div>
                      <div className="col">
                          <p> &copy;{new Date().getFullYear()} KAPIDO COFFEE.INC | ALL RIGHTS RESERVED </p>
                         
                      </div>
                      <div className="col">
                      <p>Tathkola road, Near ksrtc bus stand, mudigere(T),Chikmagalore District</p>
                      </div>
                      <div className="col"></div>
                  </div>
              </div>
          </div>
        );
    }

}

export default FooterNav;