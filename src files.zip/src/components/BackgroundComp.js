import React,{useState} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../App.css';
import  { Component } from 'react';

import { Container, Row, Col} from 'reactstrap';
import 'bootstrap/dist/css/bootstrap.css';
import { NavLink } from 'react-router-dom'

function BackgroundComp() {
   
    return (
        
      <div>
        
          
          <img src={ require('../images/coffee-background.jpg') } />
          </div>
        
        
    )}


export default BackgroundComp;