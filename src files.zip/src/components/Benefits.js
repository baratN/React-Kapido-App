import React,{useState} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../App.css';
import  { Component } from 'react';

import { Container, Row, Col} from 'reactstrap';
import 'bootstrap/dist/css/bootstrap.css';
import { NavLink } from 'react-router-dom'

function Benefits() {
   
    return (
     
      <div className="benefitsBG">
      <div class="rows">


<div class="container">

  <h2 className="benefitsCss">Nutrition value of black coffee</h2>
  <hr className="hrColor"/>  
     <h4> <p className="benefitsCss">Typically, an 8-ounce cup of black coffee contains:</p></h4>
<ul className="benefitsCss">
<li>0% fat</li>
<li>0% cholesterol</li>
<li>0% sodium</li>
<li>0% carbohydrates</li>
<li>0% sugar</li>
<li>4% potassium</li>
</ul>


<hr className="hrColor"/>
  
  <h4 > <p className="benefitsCss">Black coffee Benefits</p></h4>
<ul className="benefitsCss">
<li>It improves cardiovascular health</li>
<li>It improves your memory</li>
<li>It is good for your liver</li>
<li>It helps you cleanse your stomach</li>
<li>It may help prevent the risk of developing cancer</li>
<li>It is rich in antioxidants</li>
</ul>
<hr className="hrColor"/>
<h4> <p className="benefitsCss">About Black Coffee</p></h4>
<ul className="benefitsCss">
<li>The term ‘’Black Coffee’’ just means that the coffee is served without sugar, milk or cream its just pure coffee , nothing else .</li>
<li>Studies have shown that coffee may have health benefits, including protecting against  Parkinson’s disease, including liver cancer. Coffee also appears to improve cognitive function and decrease the risk of depression. </li>
<li>A high intake of coffee is linked to various health benefits .However , there are several ways you can improve these benefits even further. Most importantly , avoid loading your flavor with added sugar. Instead , you can flavor your coffee by adding a dash of JAGGERY.</li>
</ul>
    
</div>
</div>
       </div>
    );
  }


export default Benefits;