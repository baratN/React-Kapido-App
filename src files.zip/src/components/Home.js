
import React,{useState} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../App.css';





class Home extends React.Component {
   
  render() {

    return (
    
     <div className="centerText">
    <div >
        COFFEE & LOVE 
      </div>
      <div>
        TASTES BETTER WHEN HOT
      </div>
      </div>
      
    );
  }
}


export default Home;