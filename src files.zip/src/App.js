import React from 'react';
import logo from './images/kapidologo.png';
import backgroundimg from './images/coffee-background.jpg';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import { render } from "react-dom";
import { Image } from "react-bootstrap";
import { Row, Col, Container } from "reactstrap";

import HeaderNav from './components/HeaderNav'
import FooterNav from './components/FooterNav'
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';

import AboutUs from './components/AboutUs';
import Benefits from './components/Benefits';
import BackgroundComp from './components/BackgroundComp';
import 'react-router-dom';
import Home from './components/Home';
const Box = props => <div className="box">{props.children} </div>;





function App() {


  return (

    <div className="page-container">
      <div className="content-wrap">
        <div className="container-fluid">
          <Router>
         
            <div className="logoLettering">K A P I D O</div>
           
            <Row><HeaderNav></HeaderNav></Row>
            <Switch>
              <Route exact path="/" component={Home} />
              <Route exact path="/Home" component={Home} />
              <Route path="/AboutUs" component={AboutUs} />
              <Route path="/Benefits" component={Benefits} />
            </Switch>

          </Router>


        </div>
      </div>
      <FooterNav></FooterNav>
    </div>

  );
}



export default App;